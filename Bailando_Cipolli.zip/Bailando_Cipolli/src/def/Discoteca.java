package def;

public class Discoteca {

}
