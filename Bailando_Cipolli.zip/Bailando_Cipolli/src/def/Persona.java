package def;

public class Persona {

}
