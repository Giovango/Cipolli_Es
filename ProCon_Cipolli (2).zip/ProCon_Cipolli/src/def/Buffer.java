package def;

import java.util.LinkedList;
import java.util.Queue;

public class Buffer {
    private Queue<Integer> buffer;
    private final int MAX_SIZE = 10;

    public Buffer() {
        buffer = new LinkedList<>();
    }

    public synchronized void add(int valore) {
        while (buffer.size() == MAX_SIZE) {
            try {
                wait();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        buffer.add(valore);
        notifyAll();
    }

    public synchronized int rem() {
        while (buffer.isEmpty()) {
            try {
                wait();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        int valore = buffer.poll();
        notifyAll();
        return valore;
    }
}
