package def;

import java.util.Random;

public class Main {

    public static void main(String[] args) {
        Random random = new Random();
        int x = random.nextInt(900) + 100; // intervallo di attesa casuale
        
        Buffer b = new Buffer();
        
        Produttore p = new Produttore(b, x);
        Consumatore c = new Consumatore(b);
        
        Thread prod = new Thread(p);
        Thread cons = new Thread(c);
        
        prod.start();
        cons.start();
    }
}
