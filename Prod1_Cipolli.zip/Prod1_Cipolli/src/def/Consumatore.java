package def;

public class Consumatore implements Runnable{
	private double neg=0, x, med;
	private int time=100;
	private Buffer b;
	public Consumatore(Buffer b) {
		this.b=b;
	}
	
	public void run() {
		double[] vect=new double[5];
		int i=0;
		for(int j=0; j<5; j++) {
			vect[j]=0;
		}
		while(0<1) {
				x=b.rem();
				//si prendi qui dal buffer
				if(x<0) {
					neg++;
				}
				else {
					vect[i]=x;
					i++;
				}
			for(int j=0; j<5; j++) {
				med+=vect[j];
			}
			System.out.println("Media ultimi 5 numeri positivi "+ med);
			med=0;
			try {
	            Thread.sleep(time);
	        } catch (InterruptedException e) {
	            e.printStackTrace();
	        }
		}
	}
}