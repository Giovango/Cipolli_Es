package def;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        
        System.out.println("Inserisci il numero di consumatori");
        int C = sc.nextInt();
        Buffer b=new Buffer();
        Produttore p = new Produttore(b);
        Thread prod = new Thread(p);
        prod.start();
        
        Thread[] cons= new Thread[C];
        for(int i=0; i<C;i++) {
        	Consumatore c=new Consumatore(b);
        	cons[i]=new Thread(c);
        	cons[i].start();
        }
        sc.close();
    }
}
