package def;
import java.util.Random;

public class Produttore implements Runnable{
	private Buffer b;
	private int time;
	public Produttore(Buffer b) {
		this.b=b;
	}
	public void run() {
		Random random = new Random();
		int R;
		while(0<1) {
			R = random.nextInt(2047);
	        R-=1024;
	        b.add(R);
	        if(R<0) {
	        	time=200;
	        }
	        else {
	        	time=R/100*50;
	        }
	        try {
	            Thread.sleep(time);
	        } catch (InterruptedException e) {
	            e.printStackTrace();
	        }
	        
		}
	}
}