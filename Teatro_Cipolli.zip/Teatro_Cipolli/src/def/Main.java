package def; // Dichiarazione del pacchetto per organizzare la classe

import java.util.ArrayList; // Importazione della classe ArrayList per gestire una lista dinamica di thread

// Definizione della classe Main, punto di ingresso dell'applicazione.
public class Main {

    public static void main(String[] args) {
        final int sleepDuration = 10000; // Durata di attesa per la simulazione, in millisecondi
        final int yTeatro = 15; // Numero di righe nel teatro
        final int xTeatro = 46; // Numero di colonne nel teatro
        final int numeroThread = 7; // Numero di thread per la prenotazione dei posti
        boolean[][] matrixTeatro = new boolean[yTeatro][xTeatro]; // Matrice che rappresenta i posti del teatro
        ArrayList<Thread> listThread = new ArrayList<>(); // Lista per memorizzare i thread

        // Creazione di un oggetto Prenotatore per gestire la prenotazione dei posti
        Prenotatore prenotatore = new Prenotatore(matrixTeatro, yTeatro, xTeatro);

        // Creazione e aggiunta di thread per il prenotatore
        for (int i = 0; i < numeroThread; i++) {
            listThread.add(new Thread(prenotatore)); // Aggiunge un nuovo thread per il prenotatore
        }

        // Avvio di tutti i thread
        for (int i = 0; i < numeroThread; i++) {
            listThread.get(i).start(); // Avvia il thread corrispondente
        }

        // Pausa principale del thread principale
        try {
            Thread.sleep(sleepDuration); // Il thread principale si ferma per il tempo specificato
        } catch (InterruptedException e) {
            e.printStackTrace(); // Stampa lo stack trace in caso di interruzione
        }

        // Imposta fermo a true per fermare la prenotazione dei posti
        prenotatore.setFermo(true);

        // Attende che tutti i thread completino la loro esecuzione
        for (Thread thread : listThread) {
            try {
                thread.join(); // Aspetta che il thread termini
            } catch (InterruptedException e) {
                e.printStackTrace(); // Stampa lo stack trace in caso di interruzione
            }
        }

        // Stampa il riepilogo dei posti del cinema
        System.out.println("POSTI DEL CINEMA"
                + "\nPosti occupati: " + prenotatore.getPostiOccupati()
                + "\nPosti liberi: " + (yTeatro * xTeatro - prenotatore.getPostiOccupati())
                + "\nPosti totali: " + (yTeatro * xTeatro)
                + "\nX: posto occupato"
                + "\nO: posto libero");

        // Stampa la matrice del teatro, visualizzando i posti occupati e liberi
        for (int i = 0; i < yTeatro; i++) {
            for (int j = 0; j < xTeatro; j++) {
                if (matrixTeatro[i][j]) { // Controlla direttamente il valore booleano
                    System.out.print("X "); // Stampa "X" per un posto occupato
                } else {
                    System.out.print("O "); // Stampa "O" per un posto libero
                }
            }
            System.out.print("\n"); // Va a capo alla fine di ogni riga
        }
    }
}

