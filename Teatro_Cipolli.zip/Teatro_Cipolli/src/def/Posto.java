package def;

public class Posto {
    
    private int xPosto;
    private int yPosto;

    public Posto(int xPosto, int yPosto) {
        this.xPosto = xPosto;
        this.yPosto = yPosto;
    }

    public int getXPosto() {
        return xPosto;
    }

    public int getYPosto() {
        return yPosto;
    }

    public void setXPosto(int xPosto) {
        this.xPosto = xPosto;
    }

    public void setYPosto(int yPosto) {
        this.yPosto = yPosto;
    }
}

 