package def;

// Implementa Runnable per permettere a questa classe di essere eseguita da un thread
public class Prenotatore implements Runnable {
    
    private boolean[][] matrixTeatro; // Matrice che rappresenta i posti a teatro (true = occupato, false = libero)
    private int yTeatro; // Numero di righe nel teatro
    private int xTeatro; // Numero di colonne nel teatro
    private boolean fermo = false; // Flag per fermare il processo di prenotazione
    private Posto[] vetPostiCentrali; // Array per contenere le posizioni dei posti centrali
    private int postiOccupati = 0; // Contatore dei posti occupati

    // Costruttore che inizializza la matrice del teatro e prepara le posizioni dei posti
    public Prenotatore(boolean[][] matrixTeatro, int yTeatro, int xTeatro) {
        this.matrixTeatro = matrixTeatro;
        this.yTeatro = yTeatro;
        this.xTeatro = xTeatro;
        
        preparaPosto(); // Prepara la disposizione dei posti
    }

    // Metodo che esegue il processo di prenotazione
    public void run() {
        while (!fermo && postiOccupati < (yTeatro * xTeatro)) { // Continua finché non è fermo o tutti i posti sono occupati
            prenotaPosto(); // Prova a prenotare un posto
        }
    }

    // Metodo sincronizzato per prenotare un posto
    private synchronized void prenotaPosto() {
        // Controlla se ci sono ancora posti disponibili
        if (postiOccupati < (yTeatro * xTeatro)) {
            // Segna il posto attuale come occupato nella matrice
            matrixTeatro[vetPostiCentrali[postiOccupati].getYPosto()][vetPostiCentrali[postiOccupati].getXPosto()] = true;
            postiOccupati++; // Incrementa il conteggio dei posti occupati
        }
    }

    // Metodo per preparare le posizioni dei posti centrali in ordine spirale
    private void preparaPosto() {
        vetPostiCentrali = new Posto[yTeatro * xTeatro]; // Inizializza l'array dei posti

        int yHalf = yTeatro / 2; // Metà delle righe per il punto di partenza centrale
        int xHalf = xTeatro / 2; // Metà delle colonne per il punto di partenza centrale

        int[] dirX = {1, 0, -1, 0}; // Direzioni per il movimento lungo l'asse X (destra, giù, sinistra, su)
        int[] dirY = {0, 1, 0, -1}; // Direzioni per il movimento lungo l'asse Y (destra, giù, sinistra, su)

        int steps = 1; // Contatore per il numero di passi in ogni direzione
        int vetIndex = 0; // Indice per l'array dei posti

        // Inizializza il primo posto centrale
        vetPostiCentrali[vetIndex++] = new Posto(xHalf, yHalf);

        if (vetIndex >= yTeatro * xTeatro) return; // Controlla se l'array è pieno

        int currentX = xHalf; // Posizione attuale lungo l'asse X
        int currentY = yHalf; // Posizione attuale lungo l'asse Y

        // Loop per riempire l'array dei posti in ordine spirale
        while (vetIndex < yTeatro * xTeatro) {
            for (int d = 0; d < 4; d++) { // Per ciascuna direzione
                for (int s = 0; s < steps; s++) { // Per il numero di passi in quella direzione
                    currentX += dirX[d]; // Aggiorna la posizione X
                    currentY += dirY[d]; // Aggiorna la posizione Y

                    // Controlla se la nuova posizione è all'interno dei limiti della matrice
                    if (currentX >= 0 && currentX < xTeatro && currentY >= 0 && currentY < yTeatro) {
                        vetPostiCentrali[vetIndex++] = new Posto(currentX, currentY); // Aggiunge il posto all'array
                    }

                    if (vetIndex >= yTeatro * xTeatro) return; // Controlla se l'array è pieno
                }

                // Aumenta il numero di passi ogni due direzioni
                if (d == 1 || d == 3) {
                    steps++;
                }
            }
        }
    }

    // Getter per il numero di righe del teatro
    int getYTeatro() {
        return yTeatro;
    }
    
    // Getter per il numero di colonne del teatro
    int getXTeatro() {
        return xTeatro;
    }
    
    // Getter per il flag di arresto
    boolean getFermo() {
        return fermo;
    }
    
    // Getter per il numero di posti occupati
    int getPostiOccupati() {
        return postiOccupati;
    }

    // Setter per il numero di righe del teatro
    void setYTeatro(int yTeatro) {
        this.yTeatro = yTeatro;
    }

    // Setter per il numero di colonne del teatro
    void setXTeatro(int xTeatro) {
        this.xTeatro = xTeatro;
    }

    // Setter per il flag di arresto
    void setFermo(boolean fermo) {
        this.fermo = fermo;
    }

    // Setter per il numero di posti occupati
    void setPostiOccupati(int postiOccupati) {
        this.postiOccupati = postiOccupati;
    }
}
