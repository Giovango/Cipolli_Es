package def;
public class Contatore implements Runnable {
	 
	private int x, X=0;
	public Contatore( int x) {
		this.x=x;
	}
	public String getx(){
	    String ret;
	    if(x==X){
	        ret="COMPLETATO";
	    }
	    else{
	    	ret = String.valueOf(X);
	    }
	    return ret;
	}
	@Override
	public void run() {
	    while(x>X){
	        X++;
	        try {
                Thread.sleep(120);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
	    }
		/*for (int i = 0; i <x; i++) {
		    try {
                Thread.sleep(120);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
			String nome = Thread.currentThread().getName();
			long tid = Thread.currentThread().getId();
			System.out.printf("%5d (%5s): Sto contando %d\n", tid, nome, i);
		}*/
 
	}
 
}