package def;

import java.util.Random;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        int t, n, l=0;
        String X;
        Scanner cin = new Scanner(System.in);
        System.out.println("Quanti thread vuoi creare?\n -> ");
        t = cin.nextInt();
        String[] vect=new String[t];
        System.out.println("Qual è il valore massimo a cui contare?\n -> ");
        n = cin.nextInt();
        Random random = new Random();
        int x = random.nextInt(n);
        Contatore[] contatoriRunnable = new Contatore[t];
        Thread[] contatori = new Thread[t];
        for (int i = 0; i < contatori.length; i++) {
            Contatore c = new Contatore(n);
            contatori[i] = new Thread(c, "Thread-" + (i+1));
            contatoriRunnable[i] = c;
            contatori[i].start();
        }
         for (int i = 0; i < contatori.length; i++) {
        	 try {
                 // Il main thread aspetta per 1 secondo (1000 millisecondi)
                 Thread.sleep(1000);
             } catch (InterruptedException e) {
                 e.printStackTrace();
             }
            for (int j = 0; j < contatori.length; j++) {
            	X = contatoriRunnable[j].getx();
            	System.out.println("Thread - " + contatori[j].getName() + ": " + X);
            	if(X.equals("COMPLETATO"))
            		l++;
            }
            	
        }
        System.out.println("TUTTI I THREAD SONO COMPLETATI");
        cin.close();
    }
}